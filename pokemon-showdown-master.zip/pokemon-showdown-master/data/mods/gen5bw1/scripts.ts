export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen5',
};
