Logs of ticket stats are stored in this directory.
